package com.example.userpc.attendance;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Attendance_Frame extends AppCompatActivity
{
    TextView txt_teacher_name,txt_class_name,txt_sub_name,txt_date;

    ListView l1;
    ArrayList<String>mylist;
    ArrayAdapter<String> a;
    //Database
    SQLiteDatabase db;
    Cursor c;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance__frame);

        //DB Part starts
        db = openOrCreateDatabase("MyDB1", Context.MODE_PRIVATE, null);


        txt_teacher_name = (TextView) findViewById(R.id.txt_teacher_name);
        txt_class_name = (TextView) findViewById(R.id.txt_class_name);
        txt_sub_name = (TextView) findViewById(R.id.txt_sub_name);
        txt_date = (TextView) findViewById(R.id.txt_date);
        l1=(ListView)findViewById(R.id.list1);


        Bundle ban = getIntent().getExtras();
        txt_teacher_name.setText(""+ban.getString("para_name"));
        txt_class_name.setText(""+ban.getString("para_name1"));
        txt_sub_name.setText(""+ban.getString("para_name2"));
        txt_date.setText(""+ban.getString("para_name3"));


   /*     //Load name into mylist
        mylist=new ArrayList<String>();

        c=db.rawQuery("select distinct * from Student",null);
        while(c.moveToNext())
            mylist.add(c.getString(1));

        a=new ArrayAdapter<String>(this,R.layout.layout1,mylist);
        l1.setAdapter(a);
*/

    }
}

