package com.example.userpc.attendance;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Subject_Info extends AppCompatActivity implements AdapterView.OnItemSelectedListener,View.OnClickListener
{
    Button btn_clear, btn_insert, btn_update, btn_delete, btn_load, btn_next, btn_previous, btn_show_all;
    EditText sub_id, sub_name;

    EditText txt1;
    Spinner class_id;
    ArrayList<String> mylist;
    ArrayAdapter<String> a;

    //Database
    SQLiteDatabase db;
    Cursor c;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subject__info);

        //DB Part starts
        db = openOrCreateDatabase("MyDB1", Context.MODE_PRIVATE, null);
        db.execSQL("Create table if not exists Subject(sub_id varchar primary key,c_id varchar,sub_name varchar,FOREIGN KEY(c_id) REFERENCES Class(c_id))");
        //db.execSQL("DROP TABLE IF EXISTS Subject");

     /*   REATE TABLE orders (
            id INTEGER PRIMARY KEY,
            customer_id INTEGER,
            salesperson_id INTEGER,
            FOREIGN KEY(customer_id) REFERENCES customers(id),
            FOREIGN KEY(salesperson_id) REFERENCES salespeople(id)
    );*/

        sub_id = (EditText) findViewById(R.id.sub_id);
        sub_name = (EditText) findViewById(R.id.sub_name);

        btn_clear = findViewById(R.id.btn_clear);
        btn_insert = findViewById(R.id.btn_insert);
        btn_update = findViewById(R.id.btn_update);
        btn_delete = findViewById(R.id.btn_delete);
        btn_load = findViewById(R.id.btn_load);
        btn_next = findViewById(R.id.btn_next);
        btn_previous = findViewById(R.id.btn_previous);
        btn_show_all = findViewById(R.id.btn_show_all);

        btn_clear.setOnClickListener(this);
        btn_insert.setOnClickListener(this);
        btn_update.setOnClickListener(this);
        btn_delete.setOnClickListener(this);
        btn_load.setOnClickListener(this);
        btn_next.setOnClickListener(this);
        btn_previous.setOnClickListener(this);
        btn_show_all.setOnClickListener(this);




       class_id = (Spinner)findViewById(R.id.class_id);
        txt1 = (EditText)findViewById(R.id.txt1);

        class_id.setOnItemSelectedListener(this);

        //Load c_id into spinner
        mylist=new ArrayList<String>();

        c=db.rawQuery("select distinct c_id from Class",null);
        while(c.moveToNext())
            mylist.add(c.getString(0));

        a = new ArrayAdapter(this,android.R.layout.simple_spinner_item,mylist);
        class_id.setAdapter(a);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(getApplicationContext(),"Selected Item = "+class_id.getSelectedItem().toString(),Toast.LENGTH_SHORT).show();
        txt1.setText(class_id.getSelectedItem().toString());
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v) {
        if (v.findViewById(R.id.btn_clear) == btn_clear)
        {
            sub_id.setText("");
            sub_name.setText("");
            txt1.setText("");
        }

        if (v.findViewById(R.id.btn_insert) == btn_insert)
        {
            if (sub_id.getText().length() == 0 || sub_name.getText().length() == 0 || txt1.getText().length()==0)
                Toast.makeText(this, "All Fields Are Required", Toast.LENGTH_SHORT).show();

            else {

                String str = "insert into Subject values('" + sub_id.getText().toString() + "','" +txt1.getText().toString()  + "','" +sub_name.getText().toString()+ "')";

                db.execSQL(str);
                Toast.makeText(this, "Records Inserted Successfully....", Toast.LENGTH_SHORT).show();
                sub_id.setText("");
                sub_name.setText("");
                sub_id.setFocusable(true);

            }
        }

        if (v.findViewById(R.id.btn_update) == btn_update)
        {
            if (sub_id.getText().length() == 0 || sub_name.getText().length() == 0 || txt1.getText().length()==0)
                Toast.makeText(this, "All Fields Are Required", Toast.LENGTH_SHORT).show();

            else {

                String str = "Update Subject set sub_name ='" + sub_name.getText().toString() + "'" +
                        ",c_id = '" + txt1.getText().toString() + "' where sub_id ='" + sub_id.getText().toString() + "'";                db.execSQL(str);
                Toast.makeText(this, "Records Updated Successfully....", Toast.LENGTH_SHORT).show();
                sub_id.setText("");
                sub_name.setText("");
                txt1.setText("");
                sub_id.setFocusable(true);
            }
        }

        if (v.findViewById(R.id.btn_delete) == btn_delete) {
            if (sub_id.getText().length() == 0 || sub_name.getText().length() == 0 || txt1.getText().length()==0)
                Toast.makeText(this, "All Fields Are Required", Toast.LENGTH_SHORT).show();

            else {

                String str = "delete from Subject where sub_id = '" + sub_id.getText().toString() + "'";
                db.execSQL(str);
                Toast.makeText(this, "Records Deleted Successfully....", Toast.LENGTH_SHORT).show();
                sub_id.setText("");
                sub_name.setText("");
                txt1.setText("");
                sub_id.setFocusable(true);
            }
        }
        if (v.findViewById(R.id.btn_load) == btn_load) {
            c = db.rawQuery("select * from Subject order by sub_id", null);
            Toast.makeText(this, "Data Loaded Successfull....", Toast.LENGTH_SHORT).show();
            c.moveToFirst();
            sub_id.setText(c.getString(0));
            txt1.setText(c.getString(1));
            sub_name.setText(c.getString(2));

        }
        if (v.findViewById(R.id.btn_next) == btn_next) {
            c.moveToNext();
            if (c.isAfterLast()) {
                c.moveToPrevious();
                Toast.makeText(this, "U r On the Last Record", Toast.LENGTH_SHORT).show();
            }
            sub_id.setText(c.getString(0));
            txt1.setText(c.getString(1));
            sub_name.setText(c.getString(2));

        }
        if (v.findViewById(R.id.btn_previous) == btn_previous) {
            c.moveToPrevious();
            if (c.isBeforeFirst()) {
                c.moveToNext();
                Toast.makeText(this, "U r On the First Record", Toast.LENGTH_SHORT).show();
            }
            sub_id.setText(c.getString(0));
            txt1.setText(c.getString(1));
            sub_name.setText(c.getString(2));

        }

        if (v.findViewById(R.id.btn_show_all) == btn_show_all) {

            String temp;
            StringBuffer sb = new StringBuffer();

            c = db.rawQuery("select distinct * from Subject order by sub_id", null);
            while (c.moveToNext()) {
                sb.append("\n Subject Id = " + c.getString(0));
                sb.append("\t Subject Name = " + c.getString(1));
                sb.append("\t Class Id = " + c.getString(2));
            }
            temp = sb.toString();
            refresh("DB Records", temp);

        }
    }
    public void refresh(String ttl,String msg)
    {
        AlertDialog.Builder ad = new AlertDialog.Builder(this);
        ad.setCancelable(true);
        ad.setTitle(ttl);
        ad.setMessage(msg);
        ad.show();
    }
}
