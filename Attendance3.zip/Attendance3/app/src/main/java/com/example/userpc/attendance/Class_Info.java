package com.example.userpc.attendance;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Class_Info extends AppCompatActivity implements View.OnClickListener {
    EditText class_id, class_name, class_no;

    Button btn_clear, btn_insert, btn_update, btn_delete, btn_load, btn_next, btn_previous, btn_show_all;

    SQLiteDatabase db;
    Cursor c;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class__info);

        //DB Part starts
        db = openOrCreateDatabase("MyDB1", Context.MODE_PRIVATE, null);
        db.execSQL("Create table if not exists Class(c_id varchar primary key,c_name varchar,c_no integer)");
     //   db.execSQL("DROP TABLE IF EXISTS class");

        class_id = (EditText) findViewById(R.id.class_id);
        class_name = (EditText) findViewById(R.id.class_name);
        class_no = (EditText) findViewById(R.id.class_no);

        btn_clear = findViewById(R.id.btn_clear);
        btn_insert = findViewById(R.id.btn_insert);
        btn_update = findViewById(R.id.btn_update);
        btn_delete = findViewById(R.id.btn_delete);
        btn_load = findViewById(R.id.btn_load);
        btn_next = findViewById(R.id.btn_next);
        btn_previous = findViewById(R.id.btn_previous);
        btn_show_all = findViewById(R.id.btn_show_all);

        btn_clear.setOnClickListener(this);
        btn_insert.setOnClickListener(this);
        btn_update.setOnClickListener(this);
        btn_delete.setOnClickListener(this);
        btn_load.setOnClickListener(this);
        btn_next.setOnClickListener(this);
        btn_previous.setOnClickListener(this);
        btn_show_all.setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
            if (v.findViewById(R.id.btn_clear) == btn_clear)
            {
                class_id.setText("");
                class_name.setText("");
                class_no.setText("");
            }

            if (v.findViewById(R.id.btn_insert) == btn_insert)
            {
                if (class_id.getText().length() == 0 || class_name.getText().length() == 0 || class_no.getText().length() == 0)
                    Toast.makeText(this, "All Fields Are Required", Toast.LENGTH_SHORT).show();

                else {

                    String str = "insert into Class values('" + class_id.getText().toString() + "','" + class_name.getText().toString() + "','" + class_no.getText().toString() + "')";
                    db.execSQL(str);
                    Toast.makeText(this, "Records Inserted Successfully....", Toast.LENGTH_SHORT).show();
                    class_id.setText("");
                    class_name.setText("");
                    class_no.setText("");
                    class_id.setFocusable(true);

                }
            }

            if (v.findViewById(R.id.btn_update) == btn_update)
            {
                if (class_id.getText().length() == 0 || class_name.getText().length() == 0 || class_no.getText().length() == 0)
                    Toast.makeText(this, "All Fields Are Required", Toast.LENGTH_SHORT).show();

                else {

                    String str = "Update Class set c_name ='" + class_name.getText().toString() + "'" +
                            ",c_no = '" + class_no.getText().toString() + "'" + "    where c_id ='" + class_id.getText().toString() + "'";
                    db.execSQL(str);
                    Toast.makeText(this, "Records Updated Successfully....", Toast.LENGTH_SHORT).show();
                    class_id.setText("");
                    class_name.setText("");
                    class_no.setText("");
                    class_id.setFocusable(true);

                }
            }

            if (v.findViewById(R.id.btn_delete) == btn_delete) {
                if (class_id.getText().length() == 0 || class_name.getText().length() == 0 || class_no.getText().length() == 0)
                    Toast.makeText(this, "All Fields Are Required", Toast.LENGTH_SHORT).show();

                else {

                    String str = "delete from class where c_id = '" + class_id.getText().toString() + "'";
                    db.execSQL(str);
                    Toast.makeText(this, "Records Deleted Successfully....", Toast.LENGTH_SHORT).show();
                    class_id.setText("");
                    class_name.setText("");
                    class_no.setText("");
                    class_id.setFocusable(true);

                }
            }

            if (v.findViewById(R.id.btn_load) == btn_load) {
                c = db.rawQuery("select * from Class order by c_id", null);
                Toast.makeText(this, "Data Loaded Successfull....", Toast.LENGTH_SHORT).show();
                c.moveToFirst();
                class_id.setText(c.getString(0));
                class_name.setText(c.getString(1));
                class_no.setText(c.getString(2));
            }
            if (v.findViewById(R.id.btn_next) == btn_next) {
                c.moveToNext();
                if (c.isAfterLast()) {
                    c.moveToPrevious();
                    Toast.makeText(this, "U r On the Last Record", Toast.LENGTH_SHORT).show();
                }
                class_id.setText(c.getString(0));
                class_name.setText(c.getString(1));
                class_no.setText(c.getString(2));
            }
            if (v.findViewById(R.id.btn_previous) == btn_previous) {
                c.moveToPrevious();
                if (c.isBeforeFirst()) {
                    c.moveToNext();
                    Toast.makeText(this, "U r On the First Record", Toast.LENGTH_SHORT).show();
                }
                class_id.setText(c.getString(0));
                class_name.setText(c.getString(1));
                class_no.setText(c.getString(2));
            }

            if (v.findViewById(R.id.btn_show_all) == btn_show_all) {

                String temp;
                StringBuffer sb = new StringBuffer();

                c = db.rawQuery("select distinct * from Class order by c_id", null);
                while (c.moveToNext()) {
                    sb.append("\n Class Id = " + c.getString(0));
                    sb.append("Class Name = " + c.getString(1));
                    sb.append("Class Room No = " + c.getString(2));
                }
                temp = sb.toString();
                refresh("DB Records", temp);

            }
        }

    public void refresh(String ttl,String msg)
    {
        AlertDialog.Builder ad = new AlertDialog.Builder(this);
        ad.setCancelable(true);
        ad.setTitle(ttl);
        ad.setMessage(msg);
        ad.show();
    }
}
