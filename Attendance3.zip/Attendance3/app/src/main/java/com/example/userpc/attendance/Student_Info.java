package com.example.userpc.attendance;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class Student_Info extends AppCompatActivity implements AdapterView.OnItemSelectedListener,View.OnClickListener
{

    Button btn_clear, btn_insert, btn_update, btn_delete, btn_load, btn_next, btn_previous, btn_show_all;
    EditText stud_id, stud_name,stud_addr;

    EditText txt1,txt2;
    Spinner class_id,class_name;
    ArrayList<String> mylist1,mylist2;
    ArrayAdapter<String> adapter1,adapter2;

    //Database
    SQLiteDatabase db;
    Cursor c;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student__info);

        //DB Part starts
        db = openOrCreateDatabase("MyDB1", Context.MODE_PRIVATE, null);
        db.execSQL("Create table if not exists Student(student_id varchar primary key,c_id varchar,c_name varchar,student_name varchar,student_address,FOREIGN KEY(c_id) REFERENCES Class(c_id))");
        //db.execSQL("DROP TABLE IF EXISTS Student");

        stud_id = (EditText) findViewById(R.id.stud_id);
        stud_name = (EditText) findViewById(R.id.stud_name);
        stud_addr = (EditText)findViewById(R.id.stud_addr);

        btn_clear = findViewById(R.id.btn_clear);
        btn_insert = findViewById(R.id.btn_insert);
        btn_update = findViewById(R.id.btn_update);
        btn_delete = findViewById(R.id.btn_delete);
        btn_load = findViewById(R.id.btn_load);
        btn_next = findViewById(R.id.btn_next);
        btn_previous = findViewById(R.id.btn_previous);
        btn_show_all = findViewById(R.id.btn_show_all);

        btn_clear.setOnClickListener(this);
        btn_insert.setOnClickListener(this);
        btn_update.setOnClickListener(this);
        btn_delete.setOnClickListener(this);
        btn_load.setOnClickListener(this);
        btn_next.setOnClickListener(this);
        btn_previous.setOnClickListener(this);
        btn_show_all.setOnClickListener(this);

        class_id = (Spinner)findViewById(R.id.class_id);
        class_name = (Spinner)findViewById(R.id.class_name);


        txt1 = (EditText)findViewById(R.id.txt1);
        txt2 = (EditText)findViewById(R.id.txt2);


        class_id.setOnItemSelectedListener(this);
        class_name.setOnItemSelectedListener(this);

        //Load c_id into spinner
        mylist1=new ArrayList<String>();

        c=db.rawQuery("select distinct c_id from Class",null);
        while(c.moveToNext())
            mylist1.add(c.getString(0));

        adapter1 = new ArrayAdapter(this,android.R.layout.simple_spinner_item,mylist1);
        class_id.setAdapter(adapter1);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        //Load c_name into spinner
        mylist2=new ArrayList<String>();

        c=db.rawQuery("select distinct c_name from Class",null);
        while(c.moveToNext())
            mylist2.add(c.getString(0));

        adapter2 = new ArrayAdapter(this,android.R.layout.simple_spinner_item,mylist2);
        class_name.setAdapter(adapter2);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(getApplicationContext(),"Selected Item = "+class_id.getSelectedItem().toString(),Toast.LENGTH_SHORT).show();
        txt1.setText(class_id.getSelectedItem().toString());
        Toast.makeText(getApplicationContext(),"Selected Item = "+class_name.getSelectedItem().toString(),Toast.LENGTH_SHORT).show();
        txt2.setText(class_name.getSelectedItem().toString());
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v)
    {
        if (v.findViewById(R.id.btn_clear) == btn_clear)
        {
            stud_id.setText("");
            stud_name.setText("");
            stud_addr.setText("");
            txt1.setText("");
            txt2.setText("");

        }

        if (v.findViewById(R.id.btn_insert) == btn_insert)
        {
            if (stud_id.getText().length() == 0 || stud_name.getText().length() == 0 || stud_addr.getText().length()==0 || txt1.getText().length()==0 || txt2.getText().length()==0)
                Toast.makeText(this, "All Fields Are Required", Toast.LENGTH_SHORT).show();

            else {

                String str = "insert into Student values('" + stud_id.getText().toString() + "','"
                        +txt1.getText().toString()  + "','"+txt2.getText().toString()+"','" +stud_name.getText().toString()+ "','"+stud_addr.getText().toString()+"')";

                db.execSQL(str);
                Toast.makeText(this, "Records Inserted Successfully....", Toast.LENGTH_SHORT).show();
                stud_id.setText("");
                stud_name.setText("");
                stud_addr.setText("");
                txt1.setText("");
                txt2.setText("");
                stud_id.setFocusable(true);

            }
        }
        if (v.findViewById(R.id.btn_update) == btn_update)
        {
            if (stud_id.getText().length() == 0 || stud_name.getText().length() == 0 || stud_addr.getText().length()==0 || txt1.getText().length()==0 || txt2.getText().length()==0)
                Toast.makeText(this, "All Fields Are Required", Toast.LENGTH_SHORT).show();

            else {

                String str = "Update Student set student_name ='" + stud_name.getText().toString() + "'" +
                        ",c_id = '" + txt1.getText().toString() + "'"+
                        ",c_name = '" + txt2.getText().toString() + "'"+
                        ",student_address = '"+stud_addr.getText().toString()+"' " +
                        "where student_id ='" + stud_id.getText().toString() + "'";
                db.execSQL(str);
                Toast.makeText(this, "Records Updated Successfully....", Toast.LENGTH_SHORT).show();
                stud_id.setText("");
                stud_name.setText("");
                stud_addr.setText("");
                txt1.setText("");
                txt2.setText("");
                stud_id.setFocusable(true);

            }
        }

        if (v.findViewById(R.id.btn_delete) == btn_delete) {
            if (stud_id.getText().length() == 0 || stud_name.getText().length() == 0 || stud_addr.getText().length()==0 || txt1.getText().length()==0 || txt2.getText().length()==0)
                Toast.makeText(this, "All Fields Are Required", Toast.LENGTH_SHORT).show();

            else {

                String str = "delete from Student where student_id = '" + stud_id.getText().toString() + "'";
                db.execSQL(str);
                Toast.makeText(this, "Records Deleted Successfully....", Toast.LENGTH_SHORT).show();
                stud_id.setText("");
                stud_name.setText("");
                stud_addr.setText("");
                txt1.setText("");
                txt2.setText("");
                stud_id.setFocusable(true);
            }
        }
        if (v.findViewById(R.id.btn_load) == btn_load) {
            c = db.rawQuery("select * from Student order by student_id", null);
            Toast.makeText(this, "Data Loaded Successfull....", Toast.LENGTH_SHORT).show();
            c.moveToFirst();
            stud_id.setText(c.getString(0));
            txt1.setText(c.getString(1));
            txt2.setText(c.getString(2));
            stud_name.setText(c.getString(3));
            stud_addr.setText(c.getString(4));

        }
        if (v.findViewById(R.id.btn_next) == btn_next) {
            c.moveToNext();
            if (c.isAfterLast()) {
                c.moveToPrevious();
                Toast.makeText(this, "U r On the Last Record", Toast.LENGTH_SHORT).show();
            }
            stud_id.setText(c.getString(0));
            txt1.setText(c.getString(1));
            txt2.setText(c.getString(2));
            stud_name.setText(c.getString(3));
            stud_addr.setText(c.getString(4));

        }
        if (v.findViewById(R.id.btn_previous) == btn_previous) {
            c.moveToPrevious();
            if (c.isBeforeFirst()) {
                c.moveToNext();
                Toast.makeText(this, "U r On the First Record", Toast.LENGTH_SHORT).show();
            }
            stud_id.setText(c.getString(0));
            txt1.setText(c.getString(1));
            txt2.setText(c.getString(2));
            stud_name.setText(c.getString(3));
            stud_addr.setText(c.getString(4));

        }
        if (v.findViewById(R.id.btn_show_all) == btn_show_all) {

            String temp;
            StringBuffer sb = new StringBuffer();

            c = db.rawQuery("select distinct * from Student order by student_id", null);
            while (c.moveToNext()) {
                sb.append("\n Student Id = " + c.getString(0));
                sb.append("\t Class Id = " + c.getString(1));
                sb.append("\t Class Name = " + c.getString(2));
                sb.append("\t Student Name = " + c.getString(3));
                sb.append("\t Student Address = " + c.getString(4));

            }
            temp = sb.toString();
            refresh("DB Records", temp);
        }

    }
    public void refresh(String ttl,String msg)
    {
        AlertDialog.Builder ad = new AlertDialog.Builder(this);
        ad.setCancelable(true);
        ad.setTitle(ttl);
        ad.setMessage(msg);
        ad.show();
    }
}
