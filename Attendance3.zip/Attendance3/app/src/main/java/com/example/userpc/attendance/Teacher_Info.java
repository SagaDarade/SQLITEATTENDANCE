package com.example.userpc.attendance;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class Teacher_Info extends AppCompatActivity implements AdapterView.OnItemSelectedListener,View.OnClickListener
{

    Button btn_clear, btn_insert, btn_update, btn_delete, btn_load, btn_next, btn_previous, btn_show_all;
    EditText teach_id, teach_name,teach_sub;

    EditText txt1;
    Spinner class_id;
    ArrayList<String> mylist;
    ArrayAdapter<String> a;

    //Database
    SQLiteDatabase db;
    Cursor c;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher__info);

        //DB Part starts
        db = openOrCreateDatabase("MyDB1", Context.MODE_PRIVATE, null);
        db.execSQL("Create table if not exists Teacher(teacher_id varchar primary key,c_id varchar,teacher_name varchar,teacher_sub,FOREIGN KEY(c_id) REFERENCES Class(c_id))");

        teach_id = (EditText) findViewById(R.id.teach_id);
        teach_name = (EditText) findViewById(R.id.teach_name);
        teach_sub = (EditText)findViewById(R.id.teach_sub);

        btn_clear = findViewById(R.id.btn_clear);
        btn_insert = findViewById(R.id.btn_insert);
        btn_update = findViewById(R.id.btn_update);
        btn_delete = findViewById(R.id.btn_delete);
        btn_load = findViewById(R.id.btn_load);
        btn_next = findViewById(R.id.btn_next);
        btn_previous = findViewById(R.id.btn_previous);
        btn_show_all = findViewById(R.id.btn_show_all);

        btn_clear.setOnClickListener(this);
        btn_insert.setOnClickListener(this);
        btn_update.setOnClickListener(this);
        btn_delete.setOnClickListener(this);
        btn_load.setOnClickListener(this);
        btn_next.setOnClickListener(this);
        btn_previous.setOnClickListener(this);
        btn_show_all.setOnClickListener(this);

        class_id = (Spinner)findViewById(R.id.class_id);
        txt1 = (EditText)findViewById(R.id.txt1);

        class_id.setOnItemSelectedListener(this);

        //Load c_id into spinner
        mylist=new ArrayList<String>();

        c=db.rawQuery("select distinct c_id from Class",null);
        while(c.moveToNext())
            mylist.add(c.getString(0));

        a = new ArrayAdapter(this,android.R.layout.simple_spinner_item,mylist);
        class_id.setAdapter(a);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(getApplicationContext(),"Selected Item = "+class_id.getSelectedItem().toString(),Toast.LENGTH_SHORT).show();
        txt1.setText(class_id.getSelectedItem().toString());
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent)
    {

    }

    @Override
    public void onClick(View v)
    {
        if (v.findViewById(R.id.btn_clear) == btn_clear)
        {
            teach_id.setText("");
            teach_name.setText("");
            teach_sub.setText("");
            txt1.setText("");
        }

        if (v.findViewById(R.id.btn_insert) == btn_insert)
        {
            if (teach_id.getText().length() == 0 || teach_name.getText().length() == 0 || teach_sub.getText().length()==0 || txt1.getText().length()==0)
                Toast.makeText(this, "All Fields Are Required", Toast.LENGTH_SHORT).show();

            else {

                String str = "insert into Teacher values('" + teach_id.getText().toString() + "','"
                        +txt1.getText().toString()  + "','" +teach_name.getText().toString()+ "','"+teach_sub.getText().toString()+"')";

                db.execSQL(str);
                Toast.makeText(this, "Records Inserted Successfully....", Toast.LENGTH_SHORT).show();
                teach_id.setText("");
                teach_name.setText("");
                teach_sub.setText("");
                txt1.setText("");
                teach_id.setFocusable(true);

            }
        }

        if (v.findViewById(R.id.btn_update) == btn_update)
        {
            if (teach_id.getText().length() == 0 || teach_name.getText().length() == 0 || teach_sub.getText().length()==0 || txt1.getText().length()==0)
                Toast.makeText(this, "All Fields Are Required", Toast.LENGTH_SHORT).show();

            else {

                String str = "Update Teacher set teacher_name ='" + teach_name.getText().toString() + "'" +
                        ",c_id = '" + txt1.getText().toString() + "'"+
                        ",teacher_sub = '"+teach_sub.getText().toString()+"' " +
                        "where teacher_id ='" + teach_id.getText().toString() + "'";
                db.execSQL(str);
                Toast.makeText(this, "Records Updated Successfully....", Toast.LENGTH_SHORT).show();
                teach_id.setText("");
                teach_name.setText("");
                teach_sub.setText("");
                txt1.setText("");
                teach_id.setFocusable(true);

            }
        }
        if (v.findViewById(R.id.btn_delete) == btn_delete) {
            if (teach_id.getText().length() == 0 || teach_name.getText().length() == 0 || teach_sub.getText().length()==0 || txt1.getText().length()==0)
                Toast.makeText(this, "All Fields Are Required", Toast.LENGTH_SHORT).show();

            else {

                String str = "delete from Teacher where teacher_id = '" + teach_id.getText().toString() + "'";
                db.execSQL(str);
                Toast.makeText(this, "Records Deleted Successfully....", Toast.LENGTH_SHORT).show();
                teach_id.setText("");
                teach_name.setText("");
                teach_sub.setText("");
                txt1.setText("");
                teach_id.setFocusable(true);
            }
        }
        if (v.findViewById(R.id.btn_load) == btn_load) {
            c = db.rawQuery("select * from Teacher order by teacher_id", null);
            Toast.makeText(this, "Data Loaded Successfull....", Toast.LENGTH_SHORT).show();
            c.moveToFirst();
            teach_id.setText(c.getString(0));
            txt1.setText(c.getString(1));
            teach_name.setText(c.getString(2));
            teach_sub.setText(c.getString(3));

        }
        if (v.findViewById(R.id.btn_next) == btn_next) {
            c.moveToNext();
            if (c.isAfterLast()) {
                c.moveToPrevious();
                Toast.makeText(this, "U r On the Last Record", Toast.LENGTH_SHORT).show();
            }
            teach_id.setText(c.getString(0));
            txt1.setText(c.getString(1));
            teach_name.setText(c.getString(2));
            teach_sub.setText(c.getString(3));

        }
        if (v.findViewById(R.id.btn_previous) == btn_previous) {
            c.moveToPrevious();
            if (c.isBeforeFirst()) {
                c.moveToNext();
                Toast.makeText(this, "U r On the First Record", Toast.LENGTH_SHORT).show();
            }
            teach_id.setText(c.getString(0));
            txt1.setText(c.getString(1));
            teach_name.setText(c.getString(2));
            teach_sub.setText(c.getString(3));

        }
        if (v.findViewById(R.id.btn_show_all) == btn_show_all) {

            String temp;
            StringBuffer sb = new StringBuffer();

            c = db.rawQuery("select distinct * from Teacher order by teacher_id", null);
            while (c.moveToNext()) {
                sb.append("\n Teacher Id = " + c.getString(0));
                sb.append("\t Class Id = " + c.getString(1));
                sb.append("\t Teacher Name = " + c.getString(2));
                sb.append("\t Teacher Subject = " + c.getString(3));


            }
            temp = sb.toString();
            refresh("DB Records", temp);
        }
    }
    public void refresh(String ttl,String msg)
    {
        AlertDialog.Builder ad = new AlertDialog.Builder(this);
        ad.setCancelable(true);
        ad.setTitle(ttl);
        ad.setMessage(msg);
        ad.show();
    }
}
