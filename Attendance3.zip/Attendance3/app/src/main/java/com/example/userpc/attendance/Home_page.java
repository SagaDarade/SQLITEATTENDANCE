package com.example.userpc.attendance;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Home_page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
    }

    public void btn_class(View view)
    {
        Intent i = new Intent(this,Class_Info.class);
        startActivity(i);
    }

    public void btn_subject(View view) {
        Intent i = new Intent(this,Subject_Info.class);
        startActivity(i);

    }

    public void btn_teacher(View view) {
        Intent i = new Intent(this,Teacher_Info.class);
        startActivity(i);
    }

    public void btn_student(View view) {
        Intent i = new Intent(this,Student_Info.class);
        startActivity(i);
    }

    public void btn_attendance(View view)
    {
        Intent i = new Intent(this,Attendance_Info.class);
        startActivity(i);
    }
}
