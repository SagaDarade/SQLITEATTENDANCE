package com.example.userpc.attendance;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;

public class Attendance_Info extends AppCompatActivity implements View.OnClickListener,AdapterView.OnItemSelectedListener
{
    TextView tv1,tv2,tv3;
    Button date;
    Spinner sp_teacher,sp_cname,sp_subject;
    ArrayList<String> mylist1,mylist2,mylist3;
    ArrayAdapter<String> adapter1,adapter2,adapter3;

    DatePickerDialog datePickerDialog;
    int year;
    int month;
    int dayOfMonth;
    Calendar calendar;

    //Database
    SQLiteDatabase db;
    Cursor c;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance__info);

        //DB Part starts
        db = openOrCreateDatabase("MyDB1", Context.MODE_PRIVATE, null);

        sp_teacher = (Spinner) findViewById(R.id.sp_teacher);
        sp_cname = (Spinner) findViewById(R.id.sp_cname);
        sp_subject = (Spinner) findViewById(R.id.sp_subject);
        tv1 = (TextView) findViewById(R.id.tv1);
        tv2 = (TextView) findViewById(R.id.tv2);
        tv3 = (TextView) findViewById(R.id.tv3);
        date = (Button) findViewById(R.id.date);

        date.setOnClickListener(this);
        sp_teacher.setOnItemSelectedListener(this);
        sp_cname.setOnItemSelectedListener(this);
        sp_subject.setOnItemSelectedListener(this);

      //Load teacher_name into spinner
        mylist1 = new ArrayList<String>();

        c = db.rawQuery("select distinct teacher_name from Teacher", null);
        while (c.moveToNext())
            mylist1.add(c.getString(0));

        adapter1 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, mylist1);
        sp_teacher.setAdapter(adapter1);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //tv1.setText(sp_teacher.getSelectedItem().toString());

        //Load c_name into spinner
       mylist2 = new ArrayList<String>();

        c = db.rawQuery("select distinct c_name from Class", null);
        while (c.moveToNext())
            mylist2.add(c.getString(0));


        adapter2 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, mylist2);
        sp_cname.setAdapter(adapter2);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

       //Load subject into spinner
        mylist3 = new ArrayList<String>();

        c = db.rawQuery("select distinct sub_name from Subject", null);
        while (c.moveToNext())
            mylist3.add(c.getString(0));

        adapter3 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, mylist3);
        sp_subject.setAdapter(adapter3);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    }


    public void Submit(View view)
    {
        Intent i = new Intent(this,Attendance_Frame.class);
        Bundle  ban = new Bundle();

        // if (spinner1.isSelected())
        ban.putString("para_name",sp_teacher.getSelectedItem().toString());
        ban.putString("para_name1",sp_cname.getSelectedItem().toString());
        ban.putString("para_name2",sp_subject.getSelectedItem().toString());
        ban.putString("para_name3",date.getText().toString());
        //   ban.putString("para_name",date.getSelectedItem().toString());
        i.putExtras(ban);
        startActivity(i);
    }

    @Override
    public void onClick(View v)
    {
        if(v.findViewById(R.id.date)==date)
        {
            calendar = Calendar.getInstance();
            year = calendar.get(Calendar.YEAR);
            month = calendar.get(Calendar.MONTH);
            dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
            datePickerDialog = new DatePickerDialog(Attendance_Info.this,
                    new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                            date.setText(day + "/" + (month + 1) + "/" + year);
                        }
                    }, year, month, dayOfMonth);
            datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
            datePickerDialog.show();
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(getApplicationContext(),"Selected Item = "+sp_teacher.getSelectedItem().toString(),Toast.LENGTH_SHORT).show();
        tv1.setText(sp_teacher.getSelectedItem().toString());
       Toast.makeText(getApplicationContext(),"Selected Item = "+sp_cname.getSelectedItem().toString(),Toast.LENGTH_SHORT).show();
        tv2.setText(sp_cname.getSelectedItem().toString());
       Toast.makeText(getApplicationContext(),"Selected Item = "+sp_subject.getSelectedItem().toString(),Toast.LENGTH_SHORT).show();
        tv3.setText(sp_subject.getSelectedItem().toString());
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}

