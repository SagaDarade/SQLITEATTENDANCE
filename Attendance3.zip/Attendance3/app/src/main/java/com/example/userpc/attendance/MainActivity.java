package com.example.userpc.attendance;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText et_user, et_password;
    Button btn_login;

    SQLiteDatabase db;
    Cursor c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //DB Part starts
        db = openOrCreateDatabase("MyDB1", Context.MODE_PRIVATE, null);
        // db.execSQL("DROP TABLE IF EXISTS Login");
        db.execSQL("Create table if not exists Login(user varchar,password varchar)");
       //db.execSQL("insert into Login values('praju','praju123')");
        //db.execSQL("insert into Login values('arti','arti123')");


        et_user = (EditText) findViewById(R.id.et_user);
        et_password = (EditText) findViewById(R.id.et_password);
        btn_login = (Button) findViewById(R.id.btn_login);

        btn_login.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.findViewById(R.id.btn_login) == btn_login)
        {
            login();
        } }
   public void login()
    {
        String user = et_user.getText().toString().trim();
        String pass = et_password.getText().toString().trim();
        if(user.equals("praju") && pass.equals("praju123") || user.equals("arti") && pass.equals("arti123"))
        {
            Toast.makeText(getApplicationContext(), "Login Successfull....", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(this, Home_page.class);
            startActivity(i);
            et_user.setError("");
            et_password.setError("");
        }
        else {
            Toast.makeText(getApplicationContext(), "Invali Login....", Toast.LENGTH_SHORT).show();

        }
    }

}